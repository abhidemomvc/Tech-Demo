﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class UsersController : Controller
    {
        public ActionResult profile(User us)
        {
            return View(us);
        }
        public ActionResult Index()
        {
            List<User> PersistanceUserDetails = new List<User>();
            PersistanceUserDetails = (List<User>)TempData["User"];
            if (PersistanceUserDetails == null)
            {
                PersistanceUserDetails = new List<User>() { new User { LoginId = "SuperAdmin", Password = "SA" } };
                TempData["User"] = PersistanceUserDetails;
            }
            TempData.Keep();
            return View(PersistanceUserDetails);
        }

        // GET: Users/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                User objUserDetails = new User();

                objUserDetails.LoginId = collection.Get("LoginId");
                objUserDetails.Password = collection.Get("Password");

                List<User> PersistanceUserDetails = new List<User>();

                PersistanceUserDetails = (List<User>)TempData["User"];

                if (PersistanceUserDetails == null)
                {
                    PersistanceUserDetails = new List<User>() { new User { LoginId = "SuperAdmin", Password = "SA" } };
                }

                if (!string.IsNullOrEmpty(objUserDetails.LoginId) && !string.IsNullOrEmpty(objUserDetails.Password))
                {
                    PersistanceUserDetails.Insert(PersistanceUserDetails.Count, objUserDetails);

                    TempData["User"] = PersistanceUserDetails;
                    TempData.Keep();
                    ViewBag.Result = "User Register Successfully";
                }

                else
                {
                    TempData.Keep();
                }

                return RedirectToAction("LoginUser", PersistanceUserDetails);
            }
            catch
            {
                return View();
            }
        }

        [HttpGet]
        public ActionResult LoginUser()
        {
            return View();
        }

        [HttpPost]
        public ActionResult LoginUser(FormCollection collection)
        {
            try
            {
                User objUserDetails = new User();
                // TODO: Add insert logic here
                objUserDetails.LoginId = collection.Get("LoginId");
                objUserDetails.Password = collection.Get("Password");

                List<User> PersistanceUserDetails = new List<User>();
                PersistanceUserDetails = (List<User>)TempData["User"];
                TempData.Keep();

                if (PersistanceUserDetails == null)
                {
                    PersistanceUserDetails = new List<User>() { new User { LoginId = "SuperAdmin", Password = "SA" } };
                    TempData["User"] = PersistanceUserDetails;
                    TempData.Keep();
                }
                User objsUserDetails = PersistanceUserDetails.Where(x => x.LoginId == objUserDetails.LoginId && x.Password == objUserDetails.Password).FirstOrDefault();

                if (objsUserDetails != null)
                {
                    Session["LoginId"] = objsUserDetails.LoginId.ToString();
                    Session["Password"] = objsUserDetails.Password.ToString();

//                    ViewBag.Message = "Welcome";
                    return RedirectToAction("Dashboard", objsUserDetails);
                }
                else
                {
                    ViewBag.Message = "Please Enter Valid Username and Password";
       //            return RedirectToAction("Create");
                }
                     return View();
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Dashboard(User objsUserDetails)
        {
            return View(objsUserDetails);
        }

        public ActionResult Delete(int id)
        {
            return View();
        }

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult LogOff()
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("LoginUser");
            }
            catch
            {
                return View();
            }
        }
    }
}
